package com.modid;

import com.modid.mixin.GameRendererAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/** Dünya -> ekran projeksiyonu ve hedef çevresinde dönen beyaz ESP'ler (esp1..esp5). */
public final class Esp {
    private Esp() {}

    // ------------------------------------------------------------ projeksiyon

    public static final class Proj {
        final Vec3d cam, fwd, right, up;
        final double tan, aspect, sw, sh;

        Proj(Vec3d cam, Vec3d fwd, Vec3d right, Vec3d up, double tan, double sw, double sh) {
            this.cam = cam;
            this.fwd = fwd;
            this.right = right;
            this.up = up;
            this.tan = tan;
            this.sw = sw;
            this.sh = sh;
            this.aspect = sw / sh;
        }

        /** {x, y, derinlik} ya da kamera arkasındaysa null. */
        public double[] p(Vec3d pos) {
            Vec3d d = pos.subtract(cam);
            double f = d.dotProduct(fwd);
            if (f < 0.1) return null;
            double sx = sw / 2.0 + (d.dotProduct(right) / (f * tan * aspect)) * (sw / 2.0);
            double sy = sh / 2.0 - (d.dotProduct(up) / (f * tan)) * (sh / 2.0);
            return new double[]{sx, sy, f};
        }

        public double pixelsPerUnitAt(double depth) {
            return (sh / 2.0) / (tan * depth);
        }
    }

    public static Proj proj(MinecraftClient mc) {
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d fwd = Vec3d.fromPolar(camera.getPitch(), camera.getYaw());
        Vec3d right = fwd.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-6) return null;
        right = right.normalize();
        Vec3d up = right.crossProduct(fwd);
        float td = mc.getRenderTickCounter().getTickDelta(true);
        double fov = fovDeg(mc, camera, td);
        return new Proj(camera.getPos(), fwd, right, up, Math.tan(Math.toRadians(fov) / 2.0),
                mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
    }

    /** Oyunun gerçek (sprint/efekt dahil) FOV'u; olmazsa ayar değeri. */
    private static double fovDeg(MinecraftClient mc, Camera camera, float td) {
        try {
            return ((GameRendererAccessor) mc.gameRenderer).modid$getFov(camera, td, true);
        } catch (Throwable t) {
            return mc.options.getFov().getValue();
        }
    }

    /** Kutunun 8 köşesini projekte edip {x1,y1,x2,y2} verir; biri kamera arkasındaysa null. */
    public static int[] rect(Proj pr, Box b) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            Vec3d c = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            double[] s = pr.p(c);
            if (s == null) return null;
            minX = Math.min(minX, s[0]);
            minY = Math.min(minY, s[1]);
            maxX = Math.max(maxX, s[0]);
            maxY = Math.max(maxY, s[1]);
        }
        return new int[]{(int) minX, (int) minY, (int) maxX, (int) maxY};
    }

    // ------------------------------------------------------------ hedef ESP'leri

    public static void draw(DrawContext ctx, MinecraftClient mc, LivingEntity t, String style) {
        Proj pr = proj(mc);
        if (pr == null) return;
        float td = mc.getRenderTickCounter().getTickDelta(true);
        Vec3d base = t.getLerpedPos(td);
        double w = Math.max(0.4, t.getWidth()), h = t.getHeight();
        double time = (System.currentTimeMillis() % 100000L) / 1000.0;

        switch (style) {
            case "esp2" -> orbit(ctx, pr, base, w, h, time);
            case "esp3" -> scan(ctx, pr, base, w, h, time);
            case "esp4" -> square(ctx, pr, base.add(0, h * 0.5, 0), h, time);
            case "esp5" -> atom(ctx, pr, base.add(0, h * 0.5, 0), w, time);
            default -> ring(ctx, pr, base.add(0, 0.08, 0), w * 0.85 + 0.25, 64, time, 255, 0.45, true);
        }
    }

    /** esp1: ayakta dönen, kuyruklu parlak halka. */
    private static void ring(DrawContext c, Proj pr, Vec3d center, double r, int n, double t, int maxA, double speed, boolean comet) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            double bright = 1.0;
            if (comet) {
                double phase = ((double) i / n - t * speed) % 1.0;
                if (phase < 0) phase += 1.0;
                bright = Math.max(0.14, 1.0 - phase * 1.35);
            }
            dot(c, pr, center.add(Math.cos(a) * r, 0, Math.sin(a) * r), (int) (maxA * bright), 3);
        }
    }

    /** esp2: vücut etrafında dönen 3 parlak nokta ve uzun kuyruk. */
    private static void orbit(DrawContext c, Proj pr, Vec3d base, double w, double h, double time) {
        double r = w * 0.85 + 0.25;
        for (int k = 0; k < 3; k++) {
            for (int j = 0; j < 20; j++) {
                double tt = time - j * 0.028;
                double a = tt * 2.4 + k * Math.PI * 2 / 3;
                double y = h * (0.5 + 0.38 * Math.sin(tt * 1.5 + k * 2.1));
                int alpha = (int) (255 * Math.pow(1.0 - j / 20.0, 1.4));
                dot(c, pr, base.add(Math.cos(a) * r, y, Math.sin(a) * r), alpha, j == 0 ? 5 : 3);
            }
        }
    }

    /** esp3: vücutta aşağı yukarı gezen halka, arkasında soluk hayaletleri. */
    private static void scan(DrawContext c, Proj pr, Vec3d base, double w, double h, double time) {
        double r = w * 0.8 + 0.2;
        for (int k = 0; k < 7; k++) {
            double y = h * (0.5 + 0.5 * Math.sin((time - k * 0.05) * 1.6));
            ring(c, pr, base.add(0, y, 0), r, 44, time, (int) (255 * (1.0 - k / 7.0)), 0, false);
        }
        ring(c, pr, base.add(0, 0.05, 0), r, 24, -time, 70, 0, false);
    }

    /** esp4: ekranda dönen parlayan yuvarlak kare. */
    private static void square(DrawContext ctx, Proj pr, Vec3d pos, double height, double time) {
        double[] s = pr.p(pos);
        if (s == null) return;
        double size = Math.max(16.0, Math.min(110.0, pr.pixelsPerUnitAt(s[2]) * height * 0.9));
        int r = (int) (size / 2);
        float ang = (float) ((time % 2.4) / 2.4 * 360.0);

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(s[0], s[1], 0);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(ang));
        sq(ctx, r + 3, 3, 0x28FFFFFF);   // dış parıltı
        sq(ctx, r + 1, 2, 0x55FFFFFF);
        sq(ctx, r, 2, 0xFFFFFFFF);       // çekirdek
        m.pop();
    }

    private static void sq(DrawContext c, int r, int th, int col) {
        c.fill(-r + 4, -r, r - 4, -r + th, col);
        c.fill(-r + 4, r - th, r - 4, r, col);
        c.fill(-r, -r + 4, -r + th, r - 4, col);
        c.fill(r - th, -r + 4, r, r - 4, col);
        c.fill(-r + 2, -r + 2, -r + 4, -r + 4, col);
        c.fill(r - 4, -r + 2, r - 2, -r + 4, col);
        c.fill(-r + 2, r - 4, -r + 4, r - 2, col);
        c.fill(r - 4, r - 4, r - 2, r - 2, col);
    }

    /** esp5: iç içe dönen üç eğik halka. */
    private static void atom(DrawContext c, Proj pr, Vec3d center, double w, double time) {
        double r = w * 0.9 + 0.3;
        double[] tilts = {60, -60, 0};
        for (int ring = 0; ring < 3; ring++) {
            double tilt = Math.toRadians(tilts[ring]);
            double spin = time * (ring == 1 ? -1.6 : 1.4);
            for (int i = 0; i < 44; i++) {
                double a = Math.PI * 2 * i / 44;
                double lx = Math.cos(a) * r, lz = Math.sin(a) * r;
                double y = -lz * Math.sin(tilt), z = lz * Math.cos(tilt);
                double x2 = lx * Math.cos(spin) + z * Math.sin(spin);
                double z2 = -lx * Math.sin(spin) + z * Math.cos(spin);
                double phase = ((double) i / 44 - time * 0.5) % 1.0;
                if (phase < 0) phase += 1.0;
                double bright = Math.max(0.2, 1.0 - phase * 1.2);
                dot(c, pr, center.add(x2, y, z2), (int) (255 * bright), 3);
            }
        }
    }

    /** Parıltılı beyaz nokta. */
    private static void dot(DrawContext c, Proj pr, Vec3d p, int alpha, int size) {
        double[] s = pr.p(p);
        if (s == null) return;
        int sz = (int) Math.max(2, Math.min(size * 2 + 2, Math.round(size * 7.0 / Math.max(s[2], 1.0))));
        int x = (int) s[0] - sz / 2, y = (int) s[1] - sz / 2;
        int a = Math.max(0, Math.min(255, alpha));
        c.fill(x - 1, y - 1, x + sz + 1, y + sz + 1, ((a / 4) << 24) | 0xFFFFFF); // parıltı
        c.fill(x, y, x + sz, y + sz, (a << 24) | 0xFFFFFF);
    }
}
