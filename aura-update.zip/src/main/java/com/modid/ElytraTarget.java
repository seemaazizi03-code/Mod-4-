package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Elytra Target: hedefi kovalar, fişek basar. VURMAZ — vuruşu Aura yapar (Aura açık olmalı).
 * Silent : fişek eldeki eşya değişmeden paketle basılır.
 * Normal : eline fişek alır, yaklaşınca kılıca geçer (Aura vursun diye), uzaklaşınca fişeğe döner.
 * Legit1-5: Normal gibi ama insan gibi; seviye arttıkça fişek yavaşlar (Delay ayarı kullanılmaz).
 * Yaklaşınca yavaşlar ("biraz bekler") ki Aura vurabilsin.
 * Aura FreeLook açıksa dönüşü kamerana yansıtmaz; kapalıysa kamera da hedefe döner.
 */
public class ElytraTarget extends Module {
    public static final ElytraTarget I = new ElytraTarget();

    public final Setting.Mode mode = add(new Setting.Mode("Mode",
            new String[]{"Silent", "Normal", "Legit1", "Legit2", "Legit3", "Legit4", "Legit5"}));
    public final Setting.Bool autoFirework = add(new Setting.Bool("AutoFirework", true));
    /** 1 = çok hızlı, 1000 = ~2.5 sn'de bir fişek. Silent ve Normal için. */
    public final Setting.Num delay = add(new Setting.Num("Delay", 300, 1, 1000, 1));

    private static final int[] LEGIT_DELAY = {200, 320, 480, 700, 1000};
    private static final float[] LEGIT_ROT = {38f, 30f, 24f, 19f, 15f};
    private static final int[] LEGIT_SWAP = {1, 2, 2, 3, 4};

    public LivingEntity target;
    public Vec3d chasePoint;
    private long nextFw;
    private int wait;
    private boolean swordPhase;

    public ElytraTarget() {
        super("Elytra Target", "Combat");
    }

    @Override
    public void onDisable() {
        target = null;
        chasePoint = null;
        swordPhase = false;
        wait = 0;
        FreeLook.release(2, MinecraftClient.getInstance().player);
    }

    /** -1 = Silent, 0 = Normal, 1..5 = Legit seviyesi */
    private int level() {
        String m = mode.get();
        if (m.equals("Silent")) return -1;
        if (m.equals("Normal")) return 0;
        return m.charAt(m.length() - 1) - '0';
    }

    @Override
    public void onTick(MinecraftClient mc) {
        target = null;
        chasePoint = null;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) {
            FreeLook.release(2, null);
            return;
        }
        if (wait > 0) wait--;
        if (!p.isFallFlying()) {
            swordPhase = false;
            FreeLook.release(2, p);
            return;
        }
        if (mc.currentScreen != null) return;

        int lvl = level();
        LivingEntity t = findTarget(mc, p);
        if (t == null) {
            FreeLook.release(2, p);
            firework(mc, p, lvl, 999.0); // hedef olmasa da AutoFirework basar
            return;
        }
        target = t;

        Vec3d center = t.getPos().add(0, t.getHeight() * 0.5, 0).add(Aura.predictOffset(t));
        chasePoint = center;

        // Aura hedefe kilitliyse dönüşü ona bırak; değilse biz döneriz
        Aura aura = Modules.AURA;
        boolean auraAims = aura != null && aura.isEnabled() && aura.current != null;
        if (!auraAims) {
            if (aura != null && aura.freeLook.get()) FreeLook.acquire(2, p); // kamera serbest kalır
            else FreeLook.release(2, p);                                      // kapalıysa kamera da döner
            aim(p, center, lvl);
        }

        double dist = eyeDist(p.getEyePos(), t);
        brake(p, dist);
        firework(mc, p, lvl, dist);
        swapForFight(p, lvl, dist);
    }

    // ------------------------------------------------------------ hedef / nişan

    private LivingEntity findTarget(MinecraftClient mc, ClientPlayerEntity p) {
        PlayerEntity best = null;
        double bd = 80.0 * 80.0;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == p || !e.isAlive() || e.isSpectator() || CombatExtras.AntiBot.isBot(e)) continue;
            if (Aura.FRIENDS.contains(e.getName().getString().toLowerCase(Locale.ROOT))) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        if (best != null) return best;

        LivingEntity mob = null;
        double md = 40.0 * 40.0;
        for (net.minecraft.entity.Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !(e instanceof Monster) || !le.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d < md) {
                md = d;
                mob = le;
            }
        }
        return mob;
    }

    private void aim(ClientPlayerEntity p, Vec3d point, int lvl) {
        Vec3d d = point.subtract(p.getEyePos());
        double flat = Math.sqrt(d.x * d.x + d.z * d.z);
        float wy = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float wp = (float) -Math.toDegrees(Math.atan2(d.y, flat));

        float speed = lvl <= 0 ? 60f : LEGIT_ROT[lvl - 1];
        float ease = lvl <= 0 ? 1f : 0.45f;
        float dy = MathHelper.clamp(MathHelper.wrapDegrees(wy - p.getYaw()) * ease, -speed, speed);
        float dp = MathHelper.clamp((wp - p.getPitch()) * ease, -speed, speed);

        if (lvl > 0) { // insan gibi hafif titreme
            ThreadLocalRandom r = ThreadLocalRandom.current();
            float noise = 0.25f * lvl;
            dy += (r.nextFloat() - 0.5f) * 2f * noise;
            dp += (r.nextFloat() - 0.5f) * noise;
        }
        p.setYaw(p.getYaw() + dy);
        p.setPitch(MathHelper.clamp(p.getPitch() + dp, -90f, 90f));
    }

    private static double eyeDist(Vec3d eye, LivingEntity t) {
        Box b = t.getBoundingBox();
        double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
        double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
        double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }

    /** Hedefe yaklaşınca yavaşla: Aura'nın vurabilmesi için biraz bekle. Vuruştan sonra serbest bırak. */
    private void brake(ClientPlayerEntity p, double dist) {
        Aura a = Modules.AURA;
        if (a == null || !a.isEnabled() || dist >= 5.5) return;
        if (System.currentTimeMillis() - a.lastAttackTime() < 350) return;
        p.setVelocity(p.getVelocity().multiply(dist < 3.5 ? 0.25 : 0.6));
    }

    // ------------------------------------------------------------ fişek

    private void firework(MinecraftClient mc, ClientPlayerEntity p, int lvl, double dist) {
        if (!autoFirework.get() || wait > 0 || dist <= 4.8) return;
        long now = System.currentTimeMillis();
        if (now < nextFw) return;

        PlayerInventory inv = p.getInventory();
        boolean off = p.getOffHandStack().isOf(Items.FIREWORK_ROCKET);
        int slot = findHotbar(p, Items.FIREWORK_ROCKET);
        if (!off && slot < 0) return;

        if (off) {
            useItem(mc, p, Hand.OFF_HAND);
        } else if (lvl == -1) {
            silentUse(mc, p, slot);
        } else {
            if (inv.selectedSlot != slot) {
                inv.selectedSlot = slot;
                swordPhase = false;
                wait = lvl == 0 ? 0 : LEGIT_SWAP[lvl - 1];
                if (wait > 0) return;
            }
            useItem(mc, p, Hand.MAIN_HAND);
        }

        double base = lvl > 0 ? LEGIT_DELAY[lvl - 1] : delay.get();
        double iv = base * 2.5;
        if (lvl > 0) iv *= 0.9 + ThreadLocalRandom.current().nextDouble() * 0.2;
        nextFw = now + (long) Math.max(iv, 50);
    }

    private void useItem(MinecraftClient mc, ClientPlayerEntity p, Hand hand) {
        mc.interactionManager.interactItem(p, hand);
        p.swingHand(hand);
    }

    /** Eldeki eşyayı değiştirmeden (paketle) fişek kullan. */
    private void silentUse(MinecraftClient mc, ClientPlayerEntity p, int slot) {
        PlayerInventory inv = p.getInventory();
        int prev = inv.selectedSlot;
        if (slot == prev) {
            useItem(mc, p, Hand.MAIN_HAND);
            return;
        }
        inv.selectedSlot = slot;
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        inv.selectedSlot = prev;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(prev));
        p.swingHand(Hand.MAIN_HAND);
    }

    // ------------------------------------------------------------ kılıç / fişek geçişi (vuruşu Aura yapar)

    private void swapForFight(ClientPlayerEntity p, int lvl, double dist) {
        if (lvl == -1) return; // Silent: eldeki eşya hiç değişmez
        int ws = weaponSlot(p);
        if (ws < 0) return;
        PlayerInventory inv = p.getInventory();

        if (dist <= 4.6 && inv.selectedSlot != ws) {
            inv.selectedSlot = ws;
            swordPhase = true;
            wait = lvl == 0 ? 0 : LEGIT_SWAP[lvl - 1];
        } else if (dist > 5.5 && swordPhase && autoFirework.get()) {
            int fw = findHotbar(p, Items.FIREWORK_ROCKET);
            if (fw >= 0 && inv.selectedSlot != fw) {
                inv.selectedSlot = fw;
                wait = lvl == 0 ? 0 : LEGIT_SWAP[lvl - 1];
            }
            swordPhase = false;
        }
    }

    private static int findHotbar(ClientPlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }

    private static int weaponSlot(ClientPlayerEntity p) {
        int axe = -1, other = -1;
        for (int i = 0; i < 9; i++) {
            Item it = p.getInventory().getStack(i).getItem();
            if (it instanceof SwordItem) return i;
            if (it instanceof AxeItem && axe < 0) axe = i;
            if ((it instanceof MaceItem || it instanceof TridentItem) && other < 0) other = i;
        }
        return axe >= 0 ? axe : other;
    }
}
