package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/** Modül tuş atamaları. GUI'de modüle sağ tık -> Bind satırına bas -> bir tuşa bas. Oyunda o tuş modülü açıp kapatır. */
public final class Binds {
    private Binds() {}

    private static final Map<String, Integer> BINDS = new HashMap<>();
    private static final Map<String, Boolean> PREV = new HashMap<>();

    public static int get(Module m) {
        return BINDS.getOrDefault(m.name, -1);
    }

    public static void set(Module m, int key) {
        setRaw(m.name, key);
        Config.save();
    }

    public static void setRaw(String module, int key) {
        if (key < 0) BINDS.remove(module);
        else BINDS.put(module, key);
    }

    public static void clear() {
        BINDS.clear();
    }

    public static Map<String, Integer> all() {
        return BINDS;
    }

    public static String keyName(int key) {
        if (key < 0) return "None";
        try {
            return InputUtil.fromKeyCode(key, -1).getLocalizedText().getString();
        } catch (Throwable t) {
            return "K" + key;
        }
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.getWindow() == null) return;
        long w = mc.getWindow().getHandle();
        for (Map.Entry<String, Integer> e : BINDS.entrySet()) {
            boolean down = GLFW.glfwGetKey(w, e.getValue()) == GLFW.GLFW_PRESS;
            boolean was = PREV.getOrDefault(e.getKey(), false);
            PREV.put(e.getKey(), down);
            if (down && !was && mc.currentScreen == null) {
                for (Module m : Modules.ALL) {
                    if (m.name.equals(e.getKey())) {
                        m.toggle();
                        Config.save();
                        break;
                    }
                }
            }
        }
    }
}
