package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Gelişmiş Aura (Modules.AttackAura'nın yerini alır).
 * Modules.AURA alanının tipi Aura olmalı; eski kodun kullandığı "current" alanı korunmuştur.
 */
public class Aura extends Module {

    /** Küçük harfli oyuncu isimleri. GUI'si yok; kodla veya komutla doldur: Aura.FRIENDS.add("isim"). */
    public static final Set<String> FRIENDS = new HashSet<>();

    // ---- Saldırı
    final Setting.Mode mode = add(new Setting.Mode("Mode", new String[]{"Switch", "Single", "Multi"}));
    final Setting.Mode priority = add(new Setting.Mode("Priority", new String[]{"Distance", "Health", "Fov", "Armor"}));
    final Setting.Mode timing = add(new Setting.Mode("Timing", new String[]{"Cooldown", "Delay"}));
    final Setting.Num cpsMin = add(new Setting.Num("CPS Min", 8, 0.1, 20, 0.1));
    final Setting.Num cpsMax = add(new Setting.Num("CPS Max", 12, 0.1, 20, 0.1));
    final Setting.Num range = add(new Setting.Num("Range", 5.0, 0.1, 10, 0.1));
    final Setting.Num hitRange = add(new Setting.Num("Hit Range", 3.0, 0.1, 6, 0.1));
    final Setting.Num wallRange = add(new Setting.Num("Wall Range", 0.5, 0.1, 6, 0.1));
    final Setting.Num fov = add(new Setting.Num("FOV", 360, 0, 360, 1));

    // ---- Rotasyon
    final Setting.Mode rotMode = add(new Setting.Mode("Rotate", new String[]{"Client", "Packet", "Custom", "None"}));
    final Setting.Num yawSpeed = add(new Setting.Num("Yaw Speed", 90, 0.1, 180, 0.1));
    final Setting.Num pitchSpeed = add(new Setting.Num("Pitch Speed", 70, 0.1, 180, 0.1));
    final Setting.Bool rayTrace = add(new Setting.Bool("RayTrace", true));
    final Setting.Mode points = add(new Setting.Mode("Points", new String[]{"Head", "Chest", "Feet", "Multipoint"}));
    final Setting.Num randomize = add(new Setting.Num("Randomize", 1.0, 0, 5, 0.1));

    // ---- Kritik / kalkan
    final Setting.Bool critsOnly = add(new Setting.Bool("Criticals Only", false));
    final Setting.Bool smartCrits = add(new Setting.Bool("Smart Crits", false));
    final Setting.Bool shieldBreaker = add(new Setting.Bool("Shield Breaker", true));

    // ---- Durma koşulları
    final Setting.Bool pauseEating = add(new Setting.Bool("Pause: Eating", true));
    final Setting.Bool pauseMining = add(new Setting.Bool("Pause: Mining", true));
    final Setting.Bool pauseGui = add(new Setting.Bool("Pause: In GUI", true));

    // ---- Hedef filtresi
    final Setting.Bool players = add(new Setting.Bool("Players", true));
    final Setting.Bool mobsHostile = add(new Setting.Bool("Mobs Hostile", true));
    final Setting.Bool mobsPassive = add(new Setting.Bool("Mobs Passive", false));
    final Setting.Bool invisibles = add(new Setting.Bool("Invisibles", true));
    final Setting.Bool ignoreFriends = add(new Setting.Bool("Ignore Friends", true));
    final Setting.Bool ignoreNaked = add(new Setting.Bool("Ignore Naked", false));
    final Setting.Bool weaponOnly = add(new Setting.Bool("Weapon Only", false));
    final Setting.Bool tpsSync = add(new Setting.Bool("TPS Sync", false));

    // ---- En altta
    final Setting.Bool freeLook = add(new Setting.Bool("FreeLook", true));
    public final Setting.Bool predict = add(new Setting.Bool("Predict", false));
    public final Setting.Num predictDelay = add(new Setting.Num("Predict Delay", 3, 1, 10, 1));

    /** TargetHud vb. tarafından okunan mevcut hedef. */
    public LivingEntity current;

    private long nextAttack, lastAttack;
    private boolean hasRot;
    private float rotYaw, rotPitch;
    private double mx, my, mz;
    private boolean multiRolled;
    private int lostTicks;

    public Aura() {
        super("Aura", "Combat");
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        resync(mc);
        freeLookOff(mc.player);
        current = null;
        multiRolled = false;
    }

    // FreeLook: oyuncunun GERÇEK bakışı hedefe döner (model/sunucu görür), kamera fareyle serbest kalır.
    private void freeLookOn(ClientPlayerEntity p) {
        FreeLook.acquire(1, p);
    }

    private void freeLookOff(ClientPlayerEntity p) {
        FreeLook.release(1, p);
    }

    /** ElytraTarget / HUD için. */
    public long lastAttackTime() { return lastAttack; }

    private boolean elytraMode(ClientPlayerEntity p) {
        return p.isFallFlying() && ElytraTarget.I.isEnabled();
    }

    // ============================================================ ana döngü

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || p.isSpectator() || !p.isAlive()) {
            current = null;
            freeLookOff(p);
            return;
        }
        if ((pauseGui.get() && mc.currentScreen != null)
                || (pauseEating.get() && p.isUsingItem())
                || (pauseMining.get() && mc.interactionManager.isBreakingBlock())
                || (weaponOnly.get() && !isWeapon(p.getMainHandStack().getItem()))) {
            stop(mc);
            return;
        }

        Vec3d eye = p.getEyePos();

        // FOV 0 = TriggerBot: dönmez, sadece nişangahtaki hedefe vurur
        if (fov.get() <= 0) {
            trigger(mc, p, eye);
            return;
        }

        // --- aday listesi
        List<LivingEntity> cands = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !valid(p, le)) continue;
            if (dist(eye, le) > range.get()) continue;
            if (fov.get() < 360 && fovDiff(p, eye, le) > fov.get() / 2.0) continue;
            cands.add(le);
        }
        if (cands.isEmpty()) {
            stop(mc);
            return;
        }

        Comparator<LivingEntity> cmp;
        switch (priority.get()) {
            case "Health" -> cmp = Comparator.<LivingEntity>comparingDouble(e -> e.getHealth() + e.getAbsorptionAmount());
            case "Fov" -> cmp = Comparator.<LivingEntity>comparingDouble(e -> fovDiff(p, eye, e));
            case "Armor" -> cmp = Comparator.<LivingEntity>comparingInt(LivingEntity::getArmor);
            default -> cmp = Comparator.<LivingEntity>comparingDouble(e -> dist(eye, e));
        }
        cands.sort(cmp);

        // --- ana hedef
        LivingEntity target;
        if (mode.get().equals("Single") || mode.get().equals("Switch")) {
            target = (current != null && cands.contains(current)) ? current : cands.get(0);
        } else {
            target = cands.get(0);
        }
        current = target;
        lostTicks = 0;

        // --- FreeLook: sadece gerçek (Client/Custom) rotasyonda kamerayı ayır
        String rm = rotMode.get();
        if (freeLook.get() && !rm.equals("Packet") && !rm.equals("None")) freeLookOn(p);
        else freeLookOff(p);

        // --- rotasyon
        Vec3d aim = aimPoint(target);
        rotate(mc, p, eye, aim);

        // --- saldırı zamanı geldi mi?
        if (!ready(p)) return;
        if (!critAllowed(p, target)) return;

        List<LivingEntity> victims = new ArrayList<>();
        if (mode.get().equals("Multi")) {
            for (LivingEntity le : cands) if (inHitRange(mc, eye, le)) victims.add(le);
        } else if (inHitRange(mc, eye, target)) {
            victims.add(target);
        }
        if (victims.isEmpty()) return;

        // RayTrace / Look check yalnızca ana hedef için (Multi'de diğerleri atlanır)
        if (rayTrace.get() && !looksAt(p, eye, target)) return;

        for (LivingEntity v : victims) hit(mc, p, v);

        long now = System.currentTimeMillis();
        lastAttack = now;
        nextAttack = now + nextInterval();
        multiRolled = false;

        if (mode.get().equals("Switch") && cands.size() > 1) {
            current = cands.get((cands.indexOf(target) + 1) % cands.size());
        }
    }

    /** FOV = 0: dönmeden, nişangahın üstündeki hedefe vur. */
    private void trigger(MinecraftClient mc, ClientPlayerEntity p, Vec3d eye) {
        resync(mc);
        freeLookOff(p);
        HitResult h = mc.crosshairTarget;
        if (!(h instanceof EntityHitResult er) || !(er.getEntity() instanceof LivingEntity le) || !valid(p, le)) {
            current = null;
            return;
        }
        current = le;
        if (!ready(p) || !critAllowed(p, le) || dist(eye, le) > hitRange.get()) return;
        hit(mc, p, le);
        long now = System.currentTimeMillis();
        lastAttack = now;
        nextAttack = now + nextInterval();
    }

    // ============================================================ hedef filtresi

    private boolean valid(ClientPlayerEntity p, LivingEntity le) {
        if (le == p || !le.isAlive() || le instanceof ArmorStandEntity) return false;
        if (CombatExtras.AntiBot.isBot(le)) return false;

        boolean type = (players.get() && le instanceof PlayerEntity)
                || (mobsHostile.get() && le instanceof Monster)
                || (mobsPassive.get() && le instanceof PassiveEntity);
        if (!type) return false;

        if (!invisibles.get() && le.isInvisible()) return false;
        if (le instanceof PlayerEntity pe) {
            if (ignoreFriends.get() && FRIENDS.contains(pe.getName().getString().toLowerCase(Locale.ROOT))) return false;
            if (ignoreNaked.get() && pe.getArmor() == 0) return false;
        }
        return true;
    }

    // ============================================================ rotasyon

    private void rotate(MinecraftClient mc, ClientPlayerEntity p, Vec3d eye, Vec3d aim) {
        String rm = rotMode.get();
        if (rm.equals("None")) return;

        if (!hasRot) {
            rotYaw = p.getYaw();
            rotPitch = p.getPitch();
            hasRot = true;
        }
        boolean packet = silentRot();
        float baseYaw = packet ? rotYaw : p.getYaw();
        float basePitch = packet ? rotPitch : p.getPitch();

        Vec3d d = aim.subtract(eye);
        double flat = Math.sqrt(d.x * d.x + d.z * d.z);
        float wantYaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(d.y, flat));

        // En kısa yol: asla 360 dönmeye çalışmaz
        float dy = MathHelper.wrapDegrees(wantYaw - baseYaw);
        float dp = wantPitch - basePitch;
        if (rm.equals("Custom")) { dy *= 0.55f; dp *= 0.55f; } // yumuşatma

        // FOV büyüdükçe daha hızlı döner (360 = neredeyse anında kilitlenir)
        float mult = 1f + 2f * (float) (fov.get() / 360.0);
        float ys = Math.min(180f, (float) yawSpeed.get() * mult);
        float ps = Math.min(180f, (float) pitchSpeed.get() * mult);
        dy = MathHelper.clamp(dy, -ys, ys);
        dp = MathHelper.clamp(dp, -ps, ps);

        ThreadLocalRandom r = ThreadLocalRandom.current();
        float amp = (float) (randomize.get() * 0.2);
        float jy = amp > 0 ? (r.nextFloat() - 0.5f) * 2f * amp : 0f;
        float jp = amp > 0 ? (r.nextFloat() - 0.5f) * 2f * amp : 0f;

        float ny = baseYaw + dy + jy;
        float np = MathHelper.clamp(basePitch + dp + jp, -90f, 90f);

        if (packet) {
            rotYaw = ny;
            rotPitch = np;
            if (mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(ny, np, p.isOnGround()));
            }
        } else {
            p.setYaw(ny);
            p.setPitch(np);
        }
    }

    /** Hedef kalmadığında Packet modunda sunucudaki sahte rotasyonu gerçek bakışa geri çeker. */
    private void resync(MinecraftClient mc) {
        if (hasRot && silentRot() && mc != null && mc.player != null && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    mc.player.getYaw(), mc.player.getPitch(), mc.player.isOnGround()));
        }
        hasRot = false;
    }

    private void stop(MinecraftClient mc) {
        resync(mc);
        current = null;
        if (++lostTicks > 6) freeLookOff(mc.player); // kısa kayıplarda kamera yerinde kalır
    }

    private boolean looksAt(ClientPlayerEntity p, Vec3d eye, LivingEntity t) {
        float yaw = silentRot() ? rotYaw : p.getYaw();
        float pitch = silentRot() ? rotPitch : p.getPitch();
        Vec3d dir = Vec3d.fromPolar(pitch, yaw);
        Box box = t.getBoundingBox().offset(predictOffset(t)).expand(t.getTargetingMargin());
        Optional<Vec3d> hit = box.raycast(eye, eye.add(dir.multiply(Math.max(hitRange.get(), wallRange.get()) + 1.0)));
        return hit.isPresent() || box.contains(eye);
    }

    // ============================================================ nişan noktası / mesafe

    private Vec3d aimPoint(LivingEntity t) {
        return baseAim(t).add(predictOffset(t));
    }

    private boolean silentRot() {
        return rotMode.get().equals("Packet");
    }

    /** Predict açıksa hedefin gittiği yönde N blok ileriyi verir. */
    public static Vec3d predictOffset(Entity t) {
        Aura a = Modules.AURA;
        if (a == null || !a.isEnabled() || !a.predict.get()) return Vec3d.ZERO;
        Vec3d v = new Vec3d(t.getX() - t.prevX, t.getY() - t.prevY, t.getZ() - t.prevZ);
        double len = v.length();
        if (len < 0.03) return Vec3d.ZERO;
        return v.multiply(a.predictDelay.get() / len);
    }

    private Vec3d baseAim(LivingEntity t) {
        Box b = t.getBoundingBox();
        double cx = (b.minX + b.maxX) / 2.0, cz = (b.minZ + b.maxZ) / 2.0;
        double h = b.maxY - b.minY, w = b.maxX - b.minX;
        switch (points.get()) {
            case "Head":
                return new Vec3d(cx, t.getEyeY(), cz);
            case "Feet":
                return new Vec3d(cx, b.minY + h * 0.1, cz);
            case "Multipoint":
                if (!multiRolled) {
                    ThreadLocalRandom r = ThreadLocalRandom.current();
                    mx = (r.nextDouble() - 0.5) * w * 0.7;
                    mz = (r.nextDouble() - 0.5) * w * 0.7;
                    my = 0.2 + r.nextDouble() * 0.7;
                    multiRolled = true;
                }
                return new Vec3d(cx + mx, b.minY + h * my, cz + mz);
            default:
                return new Vec3d(cx, b.minY + h * 0.65, cz);
        }
    }

    /** Göz -> hitbox'taki en yakın nokta mesafesi (vanilla erişim mantığı). */
    private static double dist(Vec3d eye, LivingEntity t) {
        Box b = t.getBoundingBox();
        double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
        double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
        double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }

    private static double fovDiff(ClientPlayerEntity p, Vec3d eye, LivingEntity t) {
        Vec3d c = t.getBoundingBox().getCenter();
        double yaw = Math.toDegrees(Math.atan2(c.z - eye.z, c.x - eye.x)) - 90.0;
        return Math.abs(MathHelper.wrapDegrees(yaw - (FreeLook.active ? FreeLook.yaw : p.getYaw())));
    }

    private boolean inHitRange(MinecraftClient mc, Vec3d eye, LivingEntity t) {
        double d = dist(eye, t);
        boolean seen = visible(mc, eye, baseAim(t));
        return d <= (seen ? hitRange.get() : wallRange.get());
    }

    private static boolean visible(MinecraftClient mc, Vec3d from, Vec3d to) {
        BlockHitResult r = mc.world.raycast(new RaycastContext(
                from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return r.getType() == HitResult.Type.MISS;
    }

    // ============================================================ zamanlama

    private boolean ready(ClientPlayerEntity p) {
        long now = System.currentTimeMillis();
        if (timing.get().equals("Cooldown") && !elytraMode(p)) { // elytra'da cooldown beklenmez
            if (p.getAttackCooldownProgress(0.5f) < 0.92f) return false;
            if (tpsSync.get()) {
                double need = p.getAttackCooldownProgressPerTick() * 50.0 * 0.92 * tpsFactor();
                if (now - lastAttack < need) return false;
            }
            return true;
        }
        return now >= nextAttack;
    }

    private long nextInterval() {
        double lo = Math.min(cpsMin.get(), cpsMax.get());
        double hi = Math.max(cpsMin.get(), cpsMax.get());
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double cps = lo + r.nextDouble() * (hi - lo);
        double iv = 1000.0 / Math.max(cps, 0.1);
        iv *= 1.0 + (r.nextDouble() - 0.5) * 2.0 * randomize.get() * 0.04;
        if (tpsSync.get()) iv *= tpsFactor();
        return (long) iv;
    }

    private static double tpsFactor() {
        return 20.0 / Math.max(Tps.get(), 5f);
    }

    // ============================================================ kritik

    private boolean critAllowed(ClientPlayerEntity p, LivingEntity t) {
        boolean possible = !p.isClimbing() && !p.isTouchingWater() && !p.hasVehicle()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS) && !p.hasStatusEffect(StatusEffects.LEVITATION);
        boolean critNow = possible && !p.isOnGround() && p.fallDistance > 0f;

        if (critsOnly.get()) return critNow;

        if (smartCrits.get()) {
            if (t.isBlocking()) return true;                     // kalkan açık: düz vur
            if (possible && !p.isOnGround() && !critNow) return false; // havada yükseliyor: kritik için bekle
        }
        return true;
    }

    // ============================================================ vuruş

    private void hit(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        int prev = -1;
        if (shieldBreaker.get() && t.isBlocking() && !(p.getMainHandStack().getItem() instanceof AxeItem)) {
            for (int i = 0; i < 9; i++) {
                if (p.getInventory().getStack(i).getItem() instanceof AxeItem) {
                    prev = p.getInventory().selectedSlot;
                    p.getInventory().selectedSlot = i;
                    break;
                }
            }
        }
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        if (prev >= 0) p.getInventory().selectedSlot = prev;
    }

    private static boolean isWeapon(Item i) {
        return i instanceof SwordItem || i instanceof AxeItem || i instanceof MaceItem || i instanceof TridentItem;
    }
}
