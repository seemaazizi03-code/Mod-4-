package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * WexaClient ClickGUI (Nursultan tarzı).
 * Sol tık: modülü aç/kapat. Sağ tık: ayarlar (içinde Bind satırı). Orta tık: direkt tuş ata.
 * Üstte ortada Config çubuğu: isim yaz, Random, Create Config, Copy / Paste (paylaşım kodu), Config'e basınca kayıtlı liste.
 */
public class ModIDScreen extends Screen {

    private static final Set<Module> EXPANDED = new HashSet<>();
    private static String selected;
    private static String cfgName = "";

    private static final int HEADER = 22, ROW_BOOL = 15, ROW_MODE = 15, ROW_NUM = 22, ROW_BIND = 15, GAP = 6, SIDE = 104;
    private static final int BAR_W = 400, BAR_H = 22, BAR_GAP = 10;
    // bar elemanları: {x, w} (barX'e göre)
    private static final int[] E_LABEL = {0, 50}, E_NAME = {54, 108}, E_RANDOM = {166, 52},
            E_CREATE = {222, 84}, E_COPY = {310, 38}, E_PASTE = {352, 46};

    private static final String[] ADJ = {"Silent", "Shadow", "Frost", "Nova", "Viper", "Ghost", "Storm", "Hyper", "Lunar", "Blaze", "Toxic", "Rapid"};
    private static final String[] NOUN = {"Aim", "Cfg", "Legit", "Rage", "Soup", "Fury", "Flow", "Edge", "Pulse", "Wolf"};

    private final List<String> cats = new ArrayList<>();
    private int scroll;
    private Setting.Num dragNum;
    private int dragX, dragW;
    private Module binding;
    private boolean cfgFocused, cfgListOpen;
    private String cfgMsg = "";
    private long cfgMsgAt;
    private int totalH;

    private static class Card {
        Module m;
        int col, y, h;
    }

    public ModIDScreen() {
        super(Text.literal("WexaClient"));
    }

    public static boolean isEnabled(String name) {
        return Modules.isEnabled(name);
    }

    @Override
    protected void init() {
        cats.clear();
        for (String pref : new String[]{"Combat", "Movement", "Render"}) {
            for (Module m : Modules.ALL) if (m.category.equals(pref)) { cats.add(pref); break; }
        }
        for (Module m : Modules.ALL) if (!cats.contains(m.category)) cats.add(m.category);
        if (selected == null || !cats.contains(selected)) selected = cats.isEmpty() ? "" : cats.get(0);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ------------------------------------------------------------ yerleşim

    private int winW() { return Math.min(450, width - 16); }
    private int winH() { return Math.min(290, height - 16 - BAR_H - BAR_GAP); }
    private int top() { return (height - (BAR_H + BAR_GAP + winH())) / 2; }
    private int barX() { return Math.max(2, (width - BAR_W) / 2); }
    private int barY() { return top(); }
    private int winX() { return (width - winW()) / 2; }
    private int winY() { return top() + BAR_H + BAR_GAP; }
    private int cX() { return winX() + SIDE + 8; }
    private int cY() { return winY() + 30; }
    private int cW() { return winW() - SIDE - 16; }
    private int cH() { return winH() - 38; }
    private int colW() { return (cW() - GAP) / 2; }

    private static int settingH(Setting s) {
        if (s instanceof Setting.Num) return ROW_NUM;
        if (s instanceof Setting.Mode) return ROW_MODE;
        return ROW_BOOL;
    }

    private List<Card> layout() {
        List<Card> out = new ArrayList<>();
        int[] colY = {0, 0};
        for (Module m : Modules.inCategory(selected)) {
            Card c = new Card();
            c.m = m;
            int h = HEADER;
            if (EXPANDED.contains(m)) {
                h += 3 + ROW_BIND;
                for (Object o : m.settings) h += settingH((Setting) o);
                h += 3;
            }
            c.h = h;
            c.col = colY[0] <= colY[1] ? 0 : 1;
            c.y = colY[c.col];
            colY[c.col] += h + GAP;
            out.add(c);
        }
        totalH = Math.max(colY[0], colY[1]);
        return out;
    }

    private int maxScroll() {
        layout();
        return Math.max(0, totalH - cH());
    }

    // ------------------------------------------------------------ çizim

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        int x = winX(), y = winY(), w = winW(), h = winH();
        Ui.rrect(ctx, x, y, w, h, 8, Ui.BG);
        Ui.rrect(ctx, x, y, SIDE, h, 8, Ui.BG_DARK);
        ctx.fill(x + SIDE - 8, y, x + SIDE, y + h, Ui.BG_DARK);

        ctx.drawText(textRenderer, "WexaClient", x + 12, y + 12, Ui.ACCENT, true);
        ctx.fill(x + 12, y + 26, x + SIDE - 12, y + 27, 0x22FFFFFF);

        int cy = y + 36;
        for (String c : cats) {
            boolean sel = c.equals(selected);
            boolean hov = mouseX >= x + 6 && mouseX < x + SIDE - 6 && mouseY >= cy && mouseY < cy + 22;
            if (sel) Ui.rrect(ctx, x + 6, cy, SIDE - 12, 22, 5, Ui.ACCENT_DIM);
            else if (hov) Ui.rrect(ctx, x + 6, cy, SIDE - 12, 22, 5, 0x18FFFFFF);
            int on = 0;
            for (Module m : Modules.inCategory(c)) if (m.isEnabled()) on++;
            ctx.drawText(textRenderer, c, x + 14, cy + 7, sel ? Ui.ACCENT : Ui.TEXT, false);
            String cnt = String.valueOf(on);
            ctx.drawText(textRenderer, cnt, x + SIDE - 14 - textRenderer.getWidth(cnt), cy + 7, Ui.DIM, false);
            cy += 26;
        }
        ctx.drawText(textRenderer, "LMB: ac/kapat", x + 12, y + h - 39, Ui.DIM, false);
        ctx.drawText(textRenderer, "RMB: ayarlar", x + 12, y + h - 28, Ui.DIM, false);
        ctx.drawText(textRenderer, "MMB: tus ata", x + 12, y + h - 17, Ui.DIM, false);

        ctx.drawText(textRenderer, selected, cX(), y + 12, Ui.TEXT, true);

        int ms = maxScroll();
        scroll = Math.max(0, Math.min(scroll, ms));
        ctx.enableScissor(cX(), cY(), cX() + cW(), cY() + cH());
        for (Card c : layout()) {
            int cx = cX() + c.col * (colW() + GAP);
            int topY = cY() + c.y - scroll;
            if (topY + c.h < cY() || topY > cY() + cH()) continue;
            drawCard(ctx, c, cx, topY, mouseX, mouseY);
        }
        ctx.disableScissor();

        if (ms > 0) {
            int trackH = cH();
            int thumb = Math.max(16, trackH * trackH / (trackH + ms));
            int ty = cY() + (int) ((trackH - thumb) * (scroll / (double) ms));
            Ui.rrect(ctx, x + w - 6, ty, 2, thumb, 1, 0x66FFFFFF);
        }

        drawConfigBar(ctx, mouseX, mouseY);
    }

    private void drawConfigBar(DrawContext ctx, int mx, int my) {
        int bx = barX(), by = barY();
        Ui.rrect(ctx, bx - 4, by, BAR_W + 8, BAR_H, 6, Ui.BG);
        int ey = by + 3, eh = BAR_H - 6;

        boolean hovLabel = in(mx, my, bx + E_LABEL[0], ey, E_LABEL[1], eh);
        btn(ctx, bx + E_LABEL[0], ey, E_LABEL[1], eh, "Config " + (cfgListOpen ? "^" : "v"), hovLabel, false);

        // isim kutusu
        int nx = bx + E_NAME[0];
        Ui.rrect(ctx, nx, ey, E_NAME[1], eh, 4, cfgFocused ? 0xFF262B33 : Ui.TRACK);
        String shown = cfgName.isEmpty() && !cfgFocused ? "name" : cfgName;
        if (cfgFocused && (System.currentTimeMillis() / 500) % 2 == 0) shown += "_";
        ctx.drawText(textRenderer, shown, nx + 5, ey + 4, cfgName.isEmpty() && !cfgFocused ? Ui.DIM : Ui.TEXT, false);

        btn(ctx, bx + E_RANDOM[0], ey, E_RANDOM[1], eh, "Random", in(mx, my, bx + E_RANDOM[0], ey, E_RANDOM[1], eh), false);
        btn(ctx, bx + E_CREATE[0], ey, E_CREATE[1], eh, "Create Config", in(mx, my, bx + E_CREATE[0], ey, E_CREATE[1], eh), true);
        btn(ctx, bx + E_COPY[0], ey, E_COPY[1], eh, "Copy", in(mx, my, bx + E_COPY[0], ey, E_COPY[1], eh), false);
        btn(ctx, bx + E_PASTE[0], ey, E_PASTE[1], eh, "Paste", in(mx, my, bx + E_PASTE[0], ey, E_PASTE[1], eh), false);

        if (System.currentTimeMillis() - cfgMsgAt < 2500 && !cfgMsg.isEmpty()) {
            int tw = textRenderer.getWidth(cfgMsg);
            ctx.drawText(textRenderer, cfgMsg, (width - tw) / 2, by + BAR_H + 1, Ui.ACCENT, true);
        }

        if (cfgListOpen) {
            List<String> names = Config.list();
            int lx = bx + E_LABEL[0], ly = by + BAR_H + 12, lw = 190;
            int rows = Math.max(1, Math.min(names.size(), 10));
            Ui.rrect(ctx, lx, ly, lw, rows * 15 + 6, 6, Ui.BG_DARK);
            if (names.isEmpty()) {
                ctx.drawText(textRenderer, "Kayitli config yok", lx + 8, ly + 6, Ui.DIM, false);
            } else {
                for (int i = 0; i < rows; i++) {
                    int ry = ly + 3 + i * 15;
                    boolean hov = in(mx, my, lx + 3, ry, lw - 6, 15);
                    if (hov) Ui.rrect(ctx, lx + 3, ry, lw - 6, 15, 4, 0x18FFFFFF);
                    ctx.drawText(textRenderer, names.get(i), lx + 9, ry + 4, Ui.TEXT, false);
                    ctx.drawText(textRenderer, "x", lx + lw - 14, ry + 4, 0xFFE5483A, false);
                }
            }
        }
    }

    private void btn(DrawContext ctx, int x, int y, int w, int h, String text, boolean hov, boolean accent) {
        int bg = accent ? (hov ? 0xFF55E895 : Ui.ACCENT) : (hov ? 0xFF262B33 : Ui.CARD);
        Ui.rrect(ctx, x, y, w, h, 4, bg);
        ctx.drawText(textRenderer, text, x + (w - textRenderer.getWidth(text)) / 2, y + (h - 8) / 2 + 1,
                accent ? 0xFF0B0D10 : Ui.TEXT, false);
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void drawCard(DrawContext ctx, Card c, int x, int y, int mx, int my) {
        int w = colW();
        boolean on = c.m.isEnabled();
        boolean hov = in(mx, my, x, y, w, HEADER) && my >= cY() && my < cY() + cH();
        Ui.rrect(ctx, x, y, w, c.h, 5, hov ? 0xFF1C2026 : Ui.CARD);
        if (on) Ui.rrect(ctx, x, y + 4, 2, HEADER - 8, 1, Ui.ACCENT);

        ctx.drawText(textRenderer, c.m.name, x + 9, y + 7, on ? Ui.TEXT : Ui.DIM, false);
        int key = Binds.get(c.m);
        if (key >= 0 || binding == c.m) {
            String k = binding == c.m ? "..." : "[" + Binds.keyName(key) + "]";
            ctx.drawText(textRenderer, k, x + w - 32 - textRenderer.getWidth(k), y + 7, Ui.DIM, false);
        }
        drawSwitch(ctx, x + w - 26, y + 6, on);

        if (!EXPANDED.contains(c.m)) return;
        int sy = y + HEADER + 3;

        // Bind satırı
        ctx.drawText(textRenderer, "Bind", x + 9, sy + 3, Ui.TEXT, false);
        String bt = binding == c.m ? "Bir tusa bas..." : Binds.keyName(key);
        int bw = textRenderer.getWidth(bt);
        Ui.rrect(ctx, x + w - 14 - bw - 4, sy + 1, bw + 8, 12, 4, Ui.ACCENT_DIM);
        ctx.drawText(textRenderer, bt, x + w - 14 - bw, sy + 3, Ui.ACCENT, false);
        sy += ROW_BIND;

        for (Object o : c.m.settings) {
            Setting s = (Setting) o;
            drawSetting(ctx, s, x, sy, w);
            sy += settingH(s);
        }
    }

    private void drawSwitch(DrawContext ctx, int x, int y, boolean on) {
        Ui.rrect(ctx, x, y, 20, 10, 5, on ? Ui.ACCENT : Ui.TRACK);
        Ui.rrect(ctx, on ? x + 11 : x + 1, y + 1, 8, 8, 4, 0xFFFFFFFF);
    }

    private void drawSetting(DrawContext ctx, Setting s, int x, int y, int w) {
        if (s instanceof Setting.Bool b) {
            ctx.drawText(textRenderer, s.name, x + 9, y + 3, Ui.TEXT, false);
            drawSwitch(ctx, x + w - 26, y + 2, b.get());
        } else if (s instanceof Setting.Mode m) {
            ctx.drawText(textRenderer, s.name, x + 9, y + 3, Ui.TEXT, false);
            String v = m.get();
            int vw = textRenderer.getWidth(v);
            Ui.rrect(ctx, x + w - 14 - vw - 4, y + 1, vw + 8, 12, 4, Ui.ACCENT_DIM);
            ctx.drawText(textRenderer, v, x + w - 14 - vw, y + 3, Ui.ACCENT, false);
        } else if (s instanceof Setting.Num n) {
            ctx.drawText(textRenderer, s.name, x + 9, y + 2, Ui.TEXT, false);
            String v = n.display();
            ctx.drawText(textRenderer, v, x + w - 9 - textRenderer.getWidth(v), y + 2, Ui.ACCENT, false);
            int tx = x + 9, tw = w - 18, ty = y + 14;
            Ui.rrect(ctx, tx, ty, tw, 3, 1, Ui.TRACK);
            double t = (n.get() - n.min) / Math.max(1e-9, n.max - n.min);
            int fw = (int) (tw * Math.max(0, Math.min(1, t)));
            Ui.rrect(ctx, tx, ty, Math.max(2, fw), 3, 1, Ui.ACCENT);
            Ui.rrect(ctx, tx + fw - 2, ty - 1, 5, 5, 2, 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------ config işlemleri

    private void msg(String m) {
        cfgMsg = m;
        cfgMsgAt = System.currentTimeMillis();
    }

    private static String randomName() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        return ADJ[r.nextInt(ADJ.length)] + NOUN[r.nextInt(NOUN.length)] + (100 + r.nextInt(900));
    }

    private void createConfig() {
        if (Config.clean(cfgName).isEmpty()) cfgName = randomName();
        cfgName = Config.clean(cfgName);
        msg(Config.saveNamed(cfgName) ? "Config kaydedildi: " + cfgName : "Kaydedilemedi");
    }

    // ------------------------------------------------------------ fare

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int bx = barX(), by = barY(), ey = by + 3, eh = BAR_H - 6;

        // açık config listesi
        if (cfgListOpen) {
            List<String> names = Config.list();
            int lx = bx + E_LABEL[0], ly = by + BAR_H + 12, lw = 190;
            int rows = Math.max(1, Math.min(names.size(), 10));
            if (in(mx, my, lx, ly, lw, rows * 15 + 6)) {
                for (int i = 0; i < Math.min(names.size(), 10); i++) {
                    int ry = ly + 3 + i * 15;
                    if (in(mx, my, lx + 3, ry, lw - 6, 15)) {
                        if (mx >= lx + lw - 20) {
                            Config.delete(names.get(i));
                            msg("Silindi: " + names.get(i));
                        } else {
                            cfgName = names.get(i);
                            msg(Config.loadNamed(names.get(i)) ? "Yuklendi: " + names.get(i) : "Yuklenemedi");
                            cfgListOpen = false;
                        }
                        return true;
                    }
                }
                return true;
            }
        }

        // config çubuğu
        if (in(mx, my, bx - 4, by, BAR_W + 8, BAR_H)) {
            cfgFocused = false;
            if (in(mx, my, bx + E_LABEL[0], ey, E_LABEL[1], eh)) cfgListOpen = !cfgListOpen;
            else if (in(mx, my, bx + E_NAME[0], ey, E_NAME[1], eh)) cfgFocused = true;
            else if (in(mx, my, bx + E_RANDOM[0], ey, E_RANDOM[1], eh)) cfgName = randomName();
            else if (in(mx, my, bx + E_CREATE[0], ey, E_CREATE[1], eh)) createConfig();
            else if (in(mx, my, bx + E_COPY[0], ey, E_COPY[1], eh)) {
                mc.keyboard.setClipboard(Config.export());
                msg("Config kodu kopyalandi");
            } else if (in(mx, my, bx + E_PASTE[0], ey, E_PASTE[1], eh)) {
                boolean ok = Config.importCode(mc.keyboard.getClipboard(), cfgName);
                msg(ok ? "Config yuklendi" : "Gecersiz config kodu");
            }
            return true;
        }
        cfgFocused = false;
        cfgListOpen = false;

        int x = winX(), y = winY();
        int cy = y + 36;
        for (String c : cats) {
            if (in(mx, my, x + 6, cy, SIDE - 12, 22)) {
                selected = c;
                scroll = 0;
                return true;
            }
            cy += 26;
        }

        if (!in(mx, my, cX(), cY(), cW(), cH())) return super.mouseClicked(mx, my, button);

        for (Card c : layout()) {
            int cx = cX() + c.col * (colW() + GAP);
            int topY = cY() + c.y - scroll;
            int w = colW();
            if (!in(mx, my, cx, topY, w, c.h)) continue;

            if (my < topY + HEADER) {
                if (button == 0) {
                    c.m.toggle();
                    Config.save();
                } else if (button == 1) {
                    if (!EXPANDED.remove(c.m)) EXPANDED.add(c.m);
                } else if (button == 2) {
                    binding = c.m;
                }
                return true;
            }

            int sy = topY + HEADER + 3;
            if (my >= sy && my < sy + ROW_BIND) { // Bind satırı
                binding = c.m;
                return true;
            }
            sy += ROW_BIND;
            for (Object o : c.m.settings) {
                Setting s = (Setting) o;
                int sh = settingH(s);
                if (my >= sy && my < sy + sh) {
                    if (s instanceof Setting.Bool b) {
                        b.toggle();
                        Config.save();
                    } else if (s instanceof Setting.Mode m) {
                        m.next();
                        Config.save();
                    } else if (s instanceof Setting.Num n) {
                        dragNum = n;
                        dragX = cx + 9;
                        dragW = w - 18;
                        setSlider(mx);
                    }
                    return true;
                }
                sy += sh;
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void setSlider(double mx) {
        if (dragNum == null) return;
        double t = Math.max(0, Math.min(1, (mx - dragX) / (double) dragW));
        double v = dragNum.min + t * (dragNum.max - dragNum.min);
        if (dragNum.step > 0) v = Math.round((v - dragNum.min) / dragNum.step) * dragNum.step + dragNum.min;
        dragNum.set(Math.max(dragNum.min, Math.min(dragNum.max, v)));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragNum != null) {
            setSlider(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragNum != null) Config.save();
        dragNum = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) (v * 18)));
        return true;
    }

    // ------------------------------------------------------------ klavye

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding != null) { // tuş atama modu
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                // iptal
            } else if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                Binds.set(binding, -1);
            } else {
                Binds.set(binding, keyCode);
            }
            binding = null;
            return true;
        }
        if (cfgFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!cfgName.isEmpty()) cfgName = cfgName.substring(0, cfgName.length() - 1);
            } else if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                createConfig();
                cfgFocused = false;
            } else if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                cfgFocused = false;
            } else if (keyCode == GLFW.GLFW_KEY_V && Screen.hasControlDown()) {
                cfgName = Config.clean(cfgName + MinecraftClient.getInstance().keyboard.getClipboard());
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (cfgFocused) {
            if ((Character.isLetterOrDigit(chr) || chr == '_' || chr == '-') && cfgName.length() < 24) cfgName += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
