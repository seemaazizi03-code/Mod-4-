package com.modid;

import net.fabricmc.loader.api.FabricLoader;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Ayarlar: .minecraft/config/wexaclient.properties (otomatik) ve
 * .minecraft/config/wexaclient/&lt;isim&gt;.properties (kayıtlı configler). Paylaşım kodu: Copy / Paste.
 */
public final class Config {
    private Config() {}

    private static boolean loaded;

    private static Path root() { return FabricLoader.getInstance().getConfigDir(); }
    private static Path file() { return root().resolve("wexaclient.properties"); }
    private static Path dir() { return root().resolve("wexaclient"); }

    public static String clean(String n) {
        if (n == null) return "";
        String s = n.replaceAll("[^A-Za-z0-9_\\-]", "");
        return s.length() > 24 ? s.substring(0, 24) : s;
    }

    // ------------------------------------------------------------ oto kayıt

    public static void load() {
        apply(read(file()));
        loaded = true;
        Runtime.getRuntime().addShutdownHook(new Thread(Config::save));
    }

    public static synchronized void save() {
        if (!loaded) return;
        write(file(), collect());
    }

    // ------------------------------------------------------------ adlı config

    public static boolean saveNamed(String name) {
        String n = clean(name);
        if (n.isEmpty()) return false;
        write(dir().resolve(n + ".properties"), collect());
        return true;
    }

    public static boolean loadNamed(String name) {
        Path f = dir().resolve(clean(name) + ".properties");
        if (!Files.exists(f)) return false;
        apply(read(f));
        save();
        return true;
    }

    public static boolean delete(String name) {
        try {
            return Files.deleteIfExists(dir().resolve(clean(name) + ".properties"));
        } catch (IOException e) {
            return false;
        }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        if (!Files.isDirectory(dir())) return out;
        try (Stream<Path> st = Files.list(dir())) {
            st.forEach(p -> {
                String f = p.getFileName().toString();
                if (f.endsWith(".properties")) out.add(f.substring(0, f.length() - ".properties".length()));
            });
        } catch (IOException ignored) {
        }
        Collections.sort(out);
        return out;
    }

    // ------------------------------------------------------------ paylaşım kodu

    public static String export() {
        try {
            StringWriter sw = new StringWriter();
            collect().store(sw, null);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (GZIPOutputStream gz = new GZIPOutputStream(bo)) {
                gz.write(sw.toString().getBytes(StandardCharsets.UTF_8));
            }
            return "WEXA:" + Base64.getEncoder().encodeToString(bo.toByteArray());
        } catch (IOException e) {
            return "";
        }
    }

    public static boolean importCode(String code, String saveAs) {
        try {
            String c = code == null ? "" : code.trim();
            if (c.startsWith("WEXA:")) c = c.substring(5);
            byte[] raw = Base64.getDecoder().decode(c);
            String text;
            try (GZIPInputStream gz = new GZIPInputStream(new ByteArrayInputStream(raw))) {
                text = new String(gz.readAllBytes(), StandardCharsets.UTF_8);
            }
            Properties pr = new Properties();
            pr.load(new StringReader(text));
            if (pr.isEmpty()) return false;
            apply(pr);
            String n = clean(saveAs);
            if (!n.isEmpty()) write(dir().resolve(n + ".properties"), pr);
            save();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------ iç işler

    private static Properties collect() {
        Properties pr = new Properties();
        for (Module m : Modules.ALL) {
            pr.setProperty(m.name + ".__enabled", String.valueOf(m.isEnabled()));
            for (Object o : m.settings) {
                Setting s = (Setting) o;
                String v = value(s);
                if (v != null) pr.setProperty(m.name + "." + s.name, v);
            }
        }
        for (Map.Entry<String, Integer> e : Binds.all().entrySet()) pr.setProperty("bind." + e.getKey(), String.valueOf(e.getValue()));
        for (Map.Entry<String, int[]> e : HudPos.all().entrySet()) {
            pr.setProperty("hud." + e.getKey() + ".x", String.valueOf(e.getValue()[0]));
            pr.setProperty("hud." + e.getKey() + ".y", String.valueOf(e.getValue()[1]));
        }
        return pr;
    }

    private static void apply(Properties pr) {
        for (Module m : Modules.ALL) {
            for (Object o : m.settings) {
                Setting s = (Setting) o;
                applySetting(s, pr.getProperty(m.name + "." + s.name));
            }
            String en = pr.getProperty(m.name + ".__enabled");
            if (en != null) {
                boolean want = Boolean.parseBoolean(en);
                if (want != m.isEnabled()) {
                    try {
                        m.setEnabled(want);
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
        boolean anyBind = false;
        for (String k : pr.stringPropertyNames()) if (k.startsWith("bind.")) { anyBind = true; break; }
        if (anyBind) {
            Binds.clear();
            for (String k : pr.stringPropertyNames()) {
                if (!k.startsWith("bind.")) continue;
                try {
                    Binds.setRaw(k.substring(5), Integer.parseInt(pr.getProperty(k)));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        for (String k : pr.stringPropertyNames()) {
            if (k.startsWith("hud.") && k.endsWith(".x")) {
                String id = k.substring(4, k.length() - 2);
                try {
                    int x = Integer.parseInt(pr.getProperty(k));
                    int y = Integer.parseInt(pr.getProperty("hud." + id + ".y", "0"));
                    HudPos.set(id, x, y);
                } catch (NumberFormatException ignored) {
                }
            }
        }
    }

    private static Properties read(Path f) {
        Properties pr = new Properties();
        if (Files.exists(f)) {
            try (InputStream in = Files.newInputStream(f)) {
                pr.load(in);
            } catch (IOException ignored) {
            }
        }
        return pr;
    }

    private static void write(Path f, Properties pr) {
        try {
            Files.createDirectories(f.getParent());
            try (OutputStream out = Files.newOutputStream(f)) {
                pr.store(out, "WexaClient");
            }
        } catch (IOException ignored) {
        }
    }

    private static String value(Setting s) {
        if (s instanceof Setting.Bool b) return String.valueOf(b.get());
        if (s instanceof Setting.Num n) return String.valueOf(n.get());
        if (s instanceof Setting.Mode m) return m.get();
        return null;
    }

    private static void applySetting(Setting s, String v) {
        if (v == null) return;
        try {
            if (s instanceof Setting.Bool b) {
                boolean want = Boolean.parseBoolean(v);
                if (b.get() != want) b.toggle();
            } else if (s instanceof Setting.Num n) {
                n.set(Double.parseDouble(v));
            } else if (s instanceof Setting.Mode m) {
                String start = m.get();
                int guard = 0;
                do {
                    if (m.get().equals(v)) return;
                    m.next();
                } while (!m.get().equals(start) && ++guard < 64);
            }
        } catch (Throwable ignored) {
        }
    }
}
