package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** ESP: Player / Mob / Item kutuları (duvar arkasında da görünür). */
public class EspModule extends Module {
    public final Setting.Bool players = add(new Setting.Bool("Player ESP", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mob ESP", true));
    public final Setting.Bool items = add(new Setting.Bool("Item ESP", true));
    public final Setting.Mode style = add(new Setting.Mode("Style", new String[]{"Box", "Corners"}));
    public final Setting.Bool names = add(new Setting.Bool("Names", true));
    public final Setting.Bool health = add(new Setting.Bool("Health Bar", true));
    public final Setting.Num range = add(new Setting.Num("Range", 100, 10, 256, 1));

    public EspModule() {
        super("ESP", "Combat");
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        Esp.Proj pr = Esp.proj(mc);
        if (pr == null) return;
        float td = mc.getRenderTickCounter().getTickDelta(true);
        double r2 = range.get() * range.get();
        var tr = mc.textRenderer;

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || e.squaredDistanceTo(pr.cam) > r2) continue;

            boolean isPlayer = e instanceof PlayerEntity;
            boolean isItem = e instanceof ItemEntity;
            boolean isMob = e instanceof LivingEntity && !isPlayer && !(e instanceof ArmorStandEntity);
            if (!((isPlayer && players.get()) || (isMob && mobs.get()) || (isItem && items.get()))) continue;
            if (isPlayer && ((PlayerEntity) e).isSpectator()) continue;

            Vec3d off = e.getLerpedPos(td).subtract(e.getPos());
            Box b = e.getBoundingBox().offset(off);
            int[] r = Esp.rect(pr, b);
            if (r == null) continue;
            int x1 = r[0], y1 = r[1], x2 = r[2], y2 = r[3];
            if (x2 < -50 || y2 < -50 || x1 > pr.sw + 50 || y1 > pr.sh + 50) continue;
            if (x2 - x1 < 2) x2 = x1 + 2;
            if (y2 - y1 < 2) y2 = y1 + 2;

            int col = isPlayer ? Ui.ACCENT : isMob ? 0xFFFF5A4D : 0xFF5CC8FF;

            if (style.get().equals("Corners")) corners(ctx, x1, y1, x2, y2, col);
            else outline(ctx, x1, y1, x2, y2, col);

            if (health.get() && e instanceof LivingEntity le) {
                float ratio = MathHelper.clamp(le.getHealth() / Math.max(1f, le.getMaxHealth()), 0f, 1f);
                int hh = y2 - y1;
                ctx.fill(x1 - 5, y1 - 1, x1 - 2, y2 + 1, 0xAA000000);
                int hc = ratio > 0.5f ? Ui.mix(0xFFE5C14A, Ui.ACCENT, (ratio - 0.5f) * 2f) : Ui.mix(0xFFE5483A, 0xFFE5C14A, ratio * 2f);
                ctx.fill(x1 - 4, y2 - (int) (hh * ratio), x1 - 3, y2, hc);
            }

            if (names.get()) {
                String name;
                if (e instanceof ItemEntity ie) {
                    int n = ie.getStack().getCount();
                    name = ie.getStack().getName().getString() + (n > 1 ? " x" + n : "");
                } else {
                    name = e.getName().getString();
                }
                int nw = tr.getWidth(name);
                int nx = (x1 + x2) / 2 - nw / 2;
                ctx.fill(nx - 2, y1 - 12, nx + nw + 2, y1 - 2, 0x88000000);
                ctx.drawText(tr, name, nx, y1 - 11, 0xFFFFFFFF, false);
            }
        }
    }

    private static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        line(c, x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xCC000000);
        line(c, x1, y1, x2, y2, col);
    }

    private static void line(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1, x1 + 1, y2, col);
        c.fill(x2 - 1, y1, x2, y2, col);
    }

    private static void corners(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        int len = Math.max(3, Math.min(x2 - x1, y2 - y1) / 4);
        for (int pass = 0; pass < 2; pass++) {
            int o = pass == 0 ? 1 : 0;
            int cl = pass == 0 ? 0xCC000000 : col;
            c.fill(x1 - o, y1 - o, x1 + len + o, y1 + 1 + o, cl);
            c.fill(x1 - o, y1 - o, x1 + 1 + o, y1 + len + o, cl);
            c.fill(x2 - len - o, y1 - o, x2 + o, y1 + 1 + o, cl);
            c.fill(x2 - 1 - o, y1 - o, x2 + o, y1 + len + o, cl);
            c.fill(x1 - o, y2 - 1 - o, x1 + len + o, y2 + o, cl);
            c.fill(x1 - o, y2 - len - o, x1 + 1 + o, y2 + o, cl);
            c.fill(x2 - len - o, y2 - 1 - o, x2 + o, y2 + o, cl);
            c.fill(x2 - 1 - o, y2 - len - o, x2 + o, y2 + o, cl);
        }
    }
}
