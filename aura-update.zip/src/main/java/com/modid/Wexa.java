package com.modid;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

/** Tek giriş noktası: ModIDClient'te CombatExtras ve NoRender'dan SONRA Wexa.register() çağrılır. */
public final class Wexa {
    private Wexa() {}

    public static void register() {
        Modules.ALL.add(ElytraTarget.I);
        Modules.ALL.add(new ElytraMotion());
        Modules.ALL.add(new ElytraBooster());
        Modules.ALL.add(new EspModule());
        Modules.ALL.add(new KeyBinds());
        Modules.ALL.add(new WaterMark());
        Modules.ALL.add(new WexaTargetHud());

        ClientTickEvents.END_CLIENT_TICK.register(Binds::tick);
        Config.load(); // kayıtlı ayarları geri yükle (en sonda)
    }
}
