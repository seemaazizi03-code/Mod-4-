package com.modid;

import net.minecraft.client.network.ClientPlayerEntity;

/** FreeLook: kamera açısı oyuncunun gerçek bakışından ayrılır. Birden fazla modül kullanabilir (bit maskesi). */
public final class FreeLook {
    private FreeLook() {}

    public static boolean active;
    public static float yaw, pitch;
    private static int mask;

    public static void acquire(int bit, ClientPlayerEntity p) {
        if (p == null) return;
        if (!active) {
            yaw = p.getYaw();
            pitch = p.getPitch();
            active = true;
        }
        mask |= bit;
    }

    public static void release(int bit, ClientPlayerEntity p) {
        if ((mask & bit) == 0) {
            if (mask == 0 && active && p == null) active = false;
            return;
        }
        mask &= ~bit;
        if (mask == 0 && active) {
            active = false;
            if (p != null) {
                p.setYaw(yaw);
                p.setPitch(pitch);
            }
        }
    }
}
