package com.modid;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Modules {
    private Modules() {}

    public static final List<Module> ALL = new ArrayList<>();

    public static final Aura AURA = reg(new Aura());
    public static final AutoClicker AUTO_CLICKER = reg(new AutoClicker());
    public static final Sprint SPRINT = reg(new Sprint());
    public static final Fullbright FULLBRIGHT = reg(new Fullbright());
    public static final Coordinates COORDINATES = reg(new Coordinates());

    private static <T extends Module> T reg(T m) {
        ALL.add(m);
        return m;
    }

    public static List<Module> inCategory(String category) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category.equals(category)) out.add(m);
        return out;
    }

    public static boolean isEnabled(String name) {
        for (Module m : ALL) if (m.name.equals(name)) return m.isEnabled();
        return false;
    }

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) return;
            for (Module m : new ArrayList<>(ALL)) if (m.isEnabled()) m.onTick(mc);
        });
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
            for (Module m : new ArrayList<>(ALL)) if (m.isEnabled()) m.onHud(ctx, mc);
        });
    }

    // ------------------------------------------------------------ temel modüller

    public static class AutoClicker extends Module {
        public final Setting.Num cps = add(new Setting.Num("CPS", 10, 1, 20, 1));
        private int timer;

        public AutoClicker() { super("Auto Clicker", "Combat"); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
            if (timer-- > 0) return;
            timer = (int) Math.max(1, Math.round(20.0 / cps.get()));
            if (mc.crosshairTarget instanceof EntityHitResult hit && mc.interactionManager != null) {
                mc.interactionManager.attackEntity(mc.player, hit.getEntity());
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    public static class Sprint extends Module {
        public Sprint() { super("Sprint", "Movement"); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p.input.movementForward > 0 && !p.isSneaking() && !p.isUsingItem()
                    && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
            }
        }
    }

    public static class Fullbright extends Module {
        public Fullbright() { super("Fullbright", "Render"); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 400) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
            }
        }

        @Override
        public void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    public static class Coordinates extends Module {
        public Coordinates() { super("Coordinates", "Render"); }

        @Override
        public void onHud(DrawContext ctx, MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            String s = String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ());
            int[] pos = HudPos.pos("coords", 6, mc.getWindow().getScaledHeight() - 14);
            HudPos.drag(mc, "coords", pos, mc.textRenderer.getWidth(s), 10);
            ctx.drawTextWithShadow(mc.textRenderer, s, pos[0], pos[1], 0xFFFFFF);
            HudPos.outline(ctx, mc, pos[0], pos[1], mc.textRenderer.getWidth(s), 10);
        }
    }
}
