package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/** HUD kutularının konumu. Sohbet açıkken sol tık basılı tutup sürükleyerek taşınır. */
public final class HudPos {
    private HudPos() {}

    private static final Map<String, int[]> POS = new HashMap<>();
    private static final Map<String, Boolean> PREV = new HashMap<>();
    private static String dragging;
    private static int offX, offY;

    public static int[] pos(String id, int defX, int defY) {
        return POS.computeIfAbsent(id, k -> new int[]{defX, defY});
    }

    public static void set(String id, int x, int y) {
        POS.put(id, new int[]{x, y});
    }

    public static Map<String, int[]> all() {
        return POS;
    }

    /** Çizimden ÖNCE çağır; p[] dizisini günceller. */
    public static void drag(MinecraftClient mc, String id, int[] p, int w, int h) {
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        boolean chat = mc.currentScreen instanceof ChatScreen;
        boolean down = chat && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean was = PREV.getOrDefault(id, false);
        PREV.put(id, down);

        if (!down) {
            if (id.equals(dragging)) {
                dragging = null;
                Config.save();
            }
        } else {
            double mx = mc.mouse.getX() * sw / (double) mc.getWindow().getWidth();
            double my = mc.mouse.getY() * sh / (double) mc.getWindow().getHeight();
            if (dragging == null && !was && mx >= p[0] && mx < p[0] + w && my >= p[1] && my < p[1] + h) {
                dragging = id;
                offX = (int) (mx - p[0]);
                offY = (int) (my - p[1]);
            }
            if (id.equals(dragging)) {
                p[0] = Math.max(0, Math.min(sw - w, (int) mx - offX));
                p[1] = Math.max(0, Math.min(sh - h, (int) my - offY));
            }
        }
        // ekran küçülmüşse kutuyu içeri al
        p[0] = Math.max(0, Math.min(Math.max(0, sw - w), p[0]));
        p[1] = Math.max(0, Math.min(Math.max(0, sh - h), p[1]));
    }

    /** Sohbet açıkken taşınabildiğini gösteren çerçeve. */
    public static void outline(DrawContext c, MinecraftClient mc, int x, int y, int w, int h) {
        if (!(mc.currentScreen instanceof ChatScreen)) return;
        int col = Ui.ACCENT;
        c.fill(x - 1, y - 1, x + w + 1, y, col);
        c.fill(x - 1, y + h, x + w + 1, y + h + 1, col);
        c.fill(x - 1, y, x, y + h, col);
        c.fill(x + w, y, x + w + 1, y + h, col);
    }
}
