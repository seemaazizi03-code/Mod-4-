package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    /** tickNausea içinde Nausea efekti yokmuş gibi davran -> dalgalanma yoğunluğu sönümlenir. */
    @Redirect(method = "tickNausea",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;hasStatusEffect(Lnet/minecraft/registry/entry/RegistryEntry;)Z"),
            require = 0)
    private boolean modid$nausea(ClientPlayerEntity self, RegistryEntry<StatusEffect> effect) {
        if (effect == StatusEffects.NAUSEA && NoRender.on(NoRender.I.nausea)) return false;
        return self.hasStatusEffect(effect);
    }
}
