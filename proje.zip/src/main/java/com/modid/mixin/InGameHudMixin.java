package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    /** Pumpkin blur + powder snow çerçevesi. */
    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$overlay(DrawContext ctx, Identifier texture, float opacity, CallbackInfo ci) {
        String p = texture.getPath();
        if (p.contains("pumpkinblur") && NoRender.on(NoRender.I.pumpkin)) ci.cancel();
        else if (p.contains("powder_snow_outline") && NoRender.on(NoRender.I.itemOverlay)) ci.cancel();
    }

    @Inject(method = "renderSpyglassOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$spyglass(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.itemOverlay)) ci.cancel();
    }

    @Inject(method = "renderPortalOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$portal(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.portal)) ci.cancel();
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$vignette(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.vignette)) ci.cancel();
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$scoreboard(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.scoreboard)) ci.cancel();
    }
}
