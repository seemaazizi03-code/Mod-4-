package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$should(Entity entity, Frustum frustum, double x, double y, double z,
                              CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof ItemEntity && NoRender.on(NoRender.I.items)) {
            cir.setReturnValue(false);
        } else if (NoRender.entityTooFar(entity)) {
            cir.setReturnValue(false);
        }
    }
}
